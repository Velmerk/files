#!/bin/sh
./miner --algo aeternity --server ae.f2pool.com --port 7898 --user ak_v4cBSQhjh8gc49XMmrt1ELXJDA8U7sDZVKhLJiAzjPymVFgFQ
